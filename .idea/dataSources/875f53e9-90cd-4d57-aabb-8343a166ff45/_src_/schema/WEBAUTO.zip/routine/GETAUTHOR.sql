CREATE function getAuthor(auName varchar2)
return author%rowtype
is
    retval author%rowtype;
begin
    select * into retval from author where au_name=auName;
    return retval;
end;
/
