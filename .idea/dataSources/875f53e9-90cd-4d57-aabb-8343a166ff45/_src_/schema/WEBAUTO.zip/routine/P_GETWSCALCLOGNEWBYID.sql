CREATE PROCEDURE         p_getWsCalcLogNewByID(v_calcId IN NUMBER, op_cursor OUT SYS_REFCURSOR)
AS
  BEGIN
OPEN op_cursor FOR select * from WS_CALC_LOGS_NEW_TEMP_COPY w where w.calcid = v_calcId;
  END p_getWsCalcLogNewByID;
/
