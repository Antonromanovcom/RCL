CREATE PROCEDURE TESTPRM(NUM IN NUMBER, op_error_code OUT NUMBER, op_cursor OUT SYS_REFCURSOR)
AS
  BEGIN
OPEN op_cursor FOR SELECT * FROM AUTHOR yt where yt.au_id = NUM;
    EXCEPTION
    WHEN OTHERS THEN
    op_error_code := -1;

    END TESTPRM;
/
