CREATE FUNCTION getWsCalcLogNewByID (
    calcId IN NUMBER ) 
    RETURN SYS_REFCURSOR 
IS
    postAndComments SYS_REFCURSOR; 
BEGIN
   OPEN postAndComments FOR SELECT * FROM WS_CALC_LOGS_NEW_TEMP_COPY yt where yt.calcid = calcId; 
   RETURN postAndComments; 
END;
/
