CREATE PROCEDURE test_ref_cursor
is

  TYPE TCursor IS REF CURSOR;
  MyCur TCursor;
  MyRec WS_CALC_LOGS_NEW_TEMP_COPY%ROWTYPE;

begin
  P_GETWSCALCLOGNEWBYID( 190301459, MyCur );
  loop

    fetch MyCur into MyRec;
    exit when MyCur%NOTFOUND;
    dbms_output.put_line( MyRec.CALCID||' '||MyRec.CARMODELNAME  ||' '||MyRec.CARBRANDNAME );

  end loop;

  close MyCur;

END test_ref_cursor;
/
